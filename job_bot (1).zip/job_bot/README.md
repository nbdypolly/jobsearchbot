# 🤖 Job Alert Bot

Telegram-бот для поиска вакансий рекрутера/sourcer в Нидерландах и Европе.

## Источники
- LinkedIn Jobs (публичный поиск)
- Indeed Netherlands
- Careers-страницы: Adyen, Booking.com, Mollie, Optiver, Flow Traders, ASML, Picnic, TomTom, Catawiki

## Позиции
Recruiter, Technical Recruiter, Talent Acquisition Specialist, Talent Sourcer, People Analyst, HR Analyst, Campus Recruiter и подобные.

---

## 🚀 Деплой на Railway (бесплатно, 24/7)

### 1. Загрузи код на GitHub
1. Зайди на [github.com](https://github.com) → создай аккаунт если нет
2. Нажми **New repository**, назови `job-alert-bot`, создай
3. Загрузи все файлы (bot.py, scraper.py, requirements.txt, Procfile)

### 2. Задеплой на Railway
1. Зайди на [railway.app](https://railway.app)
2. Войди через GitHub
3. Нажми **New Project → Deploy from GitHub repo**
4. Выбери свой репозиторий `job-alert-bot`
5. Railway сам всё установит

### 3. Добавь переменные окружения
В Railway → твой проект → **Variables**:
```
BOT_TOKEN = 8639860393:AAGy2sh_CXx4rgedBQpsRBVyPB1v9TOML1c
CHAT_ID = 385917512
```

### 4. Готово!
Напиши боту `/start` в Telegram — он ответит и начнёт работать.

---

## 💻 Запуск локально (для теста)

```bash
pip install -r requirements.txt
python bot.py
```

---

## Команды бота
- `/start` — приветствие
- `/check` — проверить вакансии прямо сейчас
- `/status` — статус бота

## ⏰ Расписание
Автоматическая проверка каждые **6 часов**.
