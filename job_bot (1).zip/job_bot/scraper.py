import asyncio
import hashlib
import logging
import re
import sqlite3
from dataclasses import dataclass
from typing import Optional

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

DB_PATH = "jobs.db"

KEYWORDS = [
    "recruiter", "recruiting", "recruitment", "talent acquisition",
    "sourcer", "sourcing", "talent sourcer", "people analyst",
    "hr analyst", "campus recruiter", "technical recruiter",
    "tech recruiter", "talent specialist", "people operations",
]

EXCLUDE_KEYWORDS = [
    "senior manager", "director of talent", "vp of", "head of people",
    "chief people", "recruiter manager",
]

# LinkedIn public job search URLs (no auth needed)
LINKEDIN_SEARCHES = [
    "https://www.linkedin.com/jobs/search?keywords=technical+recruiter&location=Netherlands&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search?keywords=talent+acquisition+specialist&location=Netherlands&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search?keywords=talent+sourcer&location=Netherlands&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search?keywords=recruiter&location=Netherlands&f_JT=F&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search?keywords=technical+recruiter&location=Europe&f_WT=2&f_TPR=r604800",
    "https://www.linkedin.com/jobs/search?keywords=talent+acquisition&location=Europe&f_WT=2&f_TPR=r604800",
]

# Indeed Netherlands
INDEED_SEARCHES = [
    "https://nl.indeed.com/jobs?q=technical+recruiter&l=Netherlands&fromage=7",
    "https://nl.indeed.com/jobs?q=talent+acquisition+specialist&l=Netherlands&fromage=7",
    "https://nl.indeed.com/jobs?q=talent+sourcer&l=Netherlands&fromage=7",
    "https://nl.indeed.com/jobs?q=recruiter&l=Netherlands&sc=0kf%3Ajt(fulltime)%3B&fromage=7",
]

# Target company career pages: (company_name, careers_url, job_list_selector_hint)
TARGET_COMPANIES = [
    ("Adyen", "https://careers.adyen.com/vacancies?search=recruiter"),
    ("Booking.com", "https://jobs.booking.com/careers?query=recruiter"),
    ("Mollie", "https://jobs.mollie.com/?s=recruiter"),
    ("Optiver", "https://optiver.com/working-at-optiver/career-opportunities/?search=recruiter"),
    ("Flow Traders", "https://www.flowtraders.com/careers/open-positions?keyword=recruiter"),
    ("ASML", "https://www.asml.com/en/careers/find-your-job#q=recruiter&numberOfResults=10"),
    ("Picnic", "https://jobs.picnic.app/?query=recruiter"),
    ("Takeaway/JustEat", "https://careers.justeattakeaway.com/global/en/search-results?keywords=recruiter"),
    ("TomTom", "https://www.tomtom.com/careers/search/?q=recruiter"),
    ("Catawiki", "https://catawiki.com/en/jobs?search=recruiter"),
]


@dataclass
class Job:
    title: str
    company: str
    location: str
    url: str
    source: str
    job_id: str = ""

    def __post_init__(self):
        if not self.job_id:
            raw = f"{self.title}{self.company}{self.url}"
            self.job_id = hashlib.md5(raw.encode()).hexdigest()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS seen_jobs (
            job_id TEXT PRIMARY KEY,
            title TEXT,
            company TEXT,
            url TEXT,
            seen_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def is_new_job(job: Job) -> bool:
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute("SELECT 1 FROM seen_jobs WHERE job_id = ?", (job.job_id,)).fetchone()
    conn.close()
    return row is None


def mark_job_seen(job: Job):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT OR IGNORE INTO seen_jobs (job_id, title, company, url) VALUES (?, ?, ?, ?)",
        (job.job_id, job.title, job.company, job.url)
    )
    conn.commit()
    conn.close()


def is_relevant(title: str) -> bool:
    title_lower = title.lower()
    has_keyword = any(kw in title_lower for kw in KEYWORDS)
    has_exclude = any(kw in title_lower for kw in EXCLUDE_KEYWORDS)
    return has_keyword and not has_exclude


def format_message(job: Job) -> str:
    return (
        f"🆕 *{job.title}*\n"
        f"🏢 {job.company}\n"
        f"📍 {job.location}\n"
        f"🔗 [Открыть вакансию]({job.url})\n"
        f"📡 _Источник: {job.source}_"
    )


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


async def fetch(client: httpx.AsyncClient, url: str) -> Optional[str]:
    try:
        r = await client.get(url, headers=HEADERS, timeout=20, follow_redirects=True)
        if r.status_code == 200:
            return r.text
    except Exception as e:
        logger.warning(f"Failed to fetch {url}: {e}")
    return None


async def scrape_linkedin(client: httpx.AsyncClient) -> list[Job]:
    jobs = []
    for url in LINKEDIN_SEARCHES:
        html = await fetch(client, url)
        if not html:
            continue
        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select("div.base-card")
        if not cards:
            cards = soup.select("li.jobs-search__results-list > div")

        for card in cards[:20]:
            try:
                title_el = card.select_one("h3.base-search-card__title, h3")
                company_el = card.select_one("h4.base-search-card__subtitle, h4")
                location_el = card.select_one("span.job-search-card__location, span.job-result-card__location")
                link_el = card.select_one("a.base-card__full-link, a[href*='/jobs/view/']")

                if not title_el or not link_el:
                    continue

                title = title_el.get_text(strip=True)
                if not is_relevant(title):
                    continue

                company = company_el.get_text(strip=True) if company_el else "Unknown"
                location = location_el.get_text(strip=True) if location_el else "Netherlands / Remote"
                link = link_el.get("href", "").split("?")[0]
                if not link.startswith("http"):
                    link = "https://www.linkedin.com" + link

                jobs.append(Job(title=title, company=company, location=location, url=link, source="LinkedIn"))
            except Exception as e:
                logger.debug(f"LinkedIn card parse error: {e}")
        await asyncio.sleep(2)
    return jobs


async def scrape_indeed(client: httpx.AsyncClient) -> list[Job]:
    jobs = []
    for url in INDEED_SEARCHES:
        html = await fetch(client, url)
        if not html:
            continue
        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select("div.job_seen_beacon, div.jobsearch-SerpJobCard, td.resultContent")

        for card in cards[:20]:
            try:
                title_el = card.select_one("h2.jobTitle span, h2 a span, a.jcs-JobTitle span")
                company_el = card.select_one("span.companyName, [data-testid='company-name']")
                location_el = card.select_one("div.companyLocation, [data-testid='text-location']")
                link_el = card.select_one("a[href*='/pagead/'], a[id^='job_'], h2 a")

                if not title_el:
                    continue

                title = title_el.get_text(strip=True)
                if not is_relevant(title):
                    continue

                company = company_el.get_text(strip=True) if company_el else "Unknown"
                location = location_el.get_text(strip=True) if location_el else "Netherlands"
                href = link_el.get("href", "") if link_el else ""
                if href.startswith("/"):
                    link = "https://nl.indeed.com" + href
                elif href.startswith("http"):
                    link = href
                else:
                    link = url

                jobs.append(Job(title=title, company=company, location=location, url=link, source="Indeed NL"))
            except Exception as e:
                logger.debug(f"Indeed card parse error: {e}")
        await asyncio.sleep(2)
    return jobs


async def scrape_company_page(client: httpx.AsyncClient, company: str, url: str) -> list[Job]:
    jobs = []
    html = await fetch(client, url)
    if not html:
        return jobs

    soup = BeautifulSoup(html, "html.parser")

    # Generic approach: find all links that look like job postings
    for link_el in soup.find_all("a", href=True):
        try:
            title_text = link_el.get_text(strip=True)
            if len(title_text) < 5 or len(title_text) > 100:
                continue
            if not is_relevant(title_text):
                continue

            href = link_el["href"]
            if href.startswith("/"):
                from urllib.parse import urlparse
                parsed = urlparse(url)
                href = f"{parsed.scheme}://{parsed.netloc}{href}"
            elif not href.startswith("http"):
                continue

            # Try to find location near the link
            parent = link_el.parent
            location = "Netherlands"
            if parent:
                location_text = parent.get_text(" ", strip=True)
                loc_match = re.search(
                    r'(Amsterdam|Rotterdam|Utrecht|Netherlands|Remote|Hybrid|Europe)',
                    location_text, re.I
                )
                if loc_match:
                    location = loc_match.group(0)

            jobs.append(Job(
                title=title_text,
                company=company,
                location=location,
                url=href,
                source=f"Careers ({company})"
            ))
        except Exception as e:
            logger.debug(f"Company page parse error ({company}): {e}")

    return jobs[:5]  # max 5 per company to avoid spam


async def run_scraper(bot, chat_id: str) -> int:
    init_db()
    all_jobs: list[Job] = []

    async with httpx.AsyncClient() as client:
        # LinkedIn
        logger.info("Scraping LinkedIn...")
        lj = await scrape_linkedin(client)
        logger.info(f"LinkedIn: {len(lj)} jobs found")
        all_jobs.extend(lj)

        # Indeed
        logger.info("Scraping Indeed NL...")
        ij = await scrape_indeed(client)
        logger.info(f"Indeed: {len(ij)} jobs found")
        all_jobs.extend(ij)

        # Company career pages
        for company, url in TARGET_COMPANIES:
            logger.info(f"Scraping {company}...")
            cj = await scrape_company_page(client, company, url)
            logger.info(f"{company}: {len(cj)} jobs found")
            all_jobs.extend(cj)
            await asyncio.sleep(1.5)

    # Deduplicate by job_id
    seen_ids = set()
    unique_jobs = []
    for job in all_jobs:
        if job.job_id not in seen_ids:
            seen_ids.add(job.job_id)
            unique_jobs.append(job)

    # Filter only new ones
    new_jobs = [j for j in unique_jobs if is_new_job(j)]
    logger.info(f"New jobs to send: {len(new_jobs)}")

    sent = 0
    for job in new_jobs:
        try:
            await bot.send_message(
                chat_id=chat_id,
                text=format_message(job),
                parse_mode="Markdown",
                disable_web_page_preview=True,
            )
            mark_job_seen(job)
            sent += 1
            await asyncio.sleep(0.5)
        except Exception as e:
            logger.error(f"Failed to send job {job.title}: {e}")

    return sent
