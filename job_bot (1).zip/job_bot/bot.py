import asyncio
import logging
import os
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from telegram import Update
from scraper import run_scraper

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8639860393:AAGy2sh_CXx4rgedBQpsRBVyPB1v9TOML1c")
CHAT_ID = os.environ.get("CHAT_ID", "385917512")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "👋 Привет! Я буду присылать тебе новые вакансии по рекрутингу в Нидерландах и Европе.\n\n"
        "⏰ Проверяю вакансии каждые 6 часов автоматически.\n\n"
        "Команды:\n"
        "/check — проверить вакансии прямо сейчас\n"
        "/status — статус бота"
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("✅ Бот работает! Проверяю вакансии каждые 6 часов.")


async def check_now(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔍 Ищу новые вакансии...")
    count = await run_scraper(context.bot, CHAT_ID)
    if count == 0:
        await update.message.reply_text("😴 Новых вакансий не найдено.")
    else:
        await update.message.reply_text(f"✅ Готово! Найдено и отправлено: {count} новых вакансий.")


async def scheduled_check(bot, chat_id):
    logger.info("Running scheduled job check...")
    count = await run_scraper(bot, chat_id)
    logger.info(f"Scheduled check done. New jobs found: {count}")


def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("check", check_now))

    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        scheduled_check,
        "interval",
        hours=6,
        args=[app.bot, CHAT_ID],
        id="job_check"
    )
    scheduler.start()
    logger.info("Scheduler started. Checking every 6 hours.")

    app.run_polling()


if __name__ == "__main__":
    main()
